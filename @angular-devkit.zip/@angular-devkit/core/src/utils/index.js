"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const tags = require("./literals");
exports.tags = tags;
const strings = require("./strings");
exports.strings = strings;
__export(require("./object"));
__export(require("./template"));
__export(require("./priority-queue"));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiLi8iLCJzb3VyY2VzIjpbInBhY2thZ2VzL2FuZ3VsYXJfZGV2a2l0L2NvcmUvc3JjL3V0aWxzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7OztHQU1HO0FBQ0gsbUNBQW1DO0FBTzFCLG9CQUFJO0FBTmIscUNBQXFDO0FBTXRCLDBCQUFPO0FBSnRCLDhCQUF5QjtBQUN6QixnQ0FBMkI7QUFDM0Isc0NBQWlDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBJbmMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0ICogYXMgdGFncyBmcm9tICcuL2xpdGVyYWxzJztcbmltcG9ydCAqIGFzIHN0cmluZ3MgZnJvbSAnLi9zdHJpbmdzJztcblxuZXhwb3J0ICogZnJvbSAnLi9vYmplY3QnO1xuZXhwb3J0ICogZnJvbSAnLi90ZW1wbGF0ZSc7XG5leHBvcnQgKiBmcm9tICcuL3ByaW9yaXR5LXF1ZXVlJztcblxuZXhwb3J0IHsgdGFncywgc3RyaW5ncyB9O1xuIl19
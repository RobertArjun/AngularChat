import { TemplateInfo } from './common';
import { Completions } from './types';
export declare function getTemplateCompletions(templateInfo: TemplateInfo): Completions | undefined;

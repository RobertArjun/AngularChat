/**
 * @license Angular v5.2.8
 * (c) 2010-2018 Google, Inc. https://angular.io/
 * License: MIT
 */ 
 export * from './animations/animations'

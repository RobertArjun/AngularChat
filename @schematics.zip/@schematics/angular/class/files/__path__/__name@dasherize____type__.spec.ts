import { <%= classify(name) %> } from './<%= dasherize(name) %><%= type %>';

describe('<%= classify(name) %>', () => {
  it('should create an instance', () => {
    expect(new <%= classify(name) %>()).toBeTruthy();
  });
});

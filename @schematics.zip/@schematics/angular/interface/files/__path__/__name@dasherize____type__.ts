export interface <%= prefix %><%= classify(name) %> {
}

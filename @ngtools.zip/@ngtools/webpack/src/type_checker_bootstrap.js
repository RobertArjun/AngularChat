require('../../../../lib/bootstrap-local');
require('./type_checker_worker.ts');

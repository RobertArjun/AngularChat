import { InjectionToken } from '@angular/core';
export declare const EnablePersistenceToken: InjectionToken<boolean>;

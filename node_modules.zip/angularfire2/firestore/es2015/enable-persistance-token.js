import { InjectionToken } from '@angular/core';
export const EnablePersistenceToken = new InjectionToken('EnablePersistenceToken');
//# sourceMappingURL=enable-persistance-token.js.map
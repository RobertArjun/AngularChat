import { InjectionToken } from '@angular/core';
export var EnablePersistenceToken = new InjectionToken('EnablePersistenceToken');
//# sourceMappingURL=enable-persistance-token.js.map
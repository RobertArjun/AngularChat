export * from './public_api';
export { _firebaseAppFactory as ɵa } from './firebase.app.module';

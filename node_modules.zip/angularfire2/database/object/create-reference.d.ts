import { DatabaseQuery, AngularFireObject } from '../interfaces';
export declare function createObjectReference<T>(query: DatabaseQuery): AngularFireObject<T>;

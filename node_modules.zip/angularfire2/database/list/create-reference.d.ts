import { DatabaseQuery, AngularFireList } from '../interfaces';
export declare function createListReference<T>(query: DatabaseQuery): AngularFireList<T>;

![Nodemailer](https://raw.githubusercontent.com/nodemailer/nodemailer/master/assets/nm_logo_200x136.png)

Send e-mails from Node.js – easy as cake! 🍰✉️

<a href="http://badge.fury.io/js/nodemailer"><img src="https://badge.fury.io/js/nodemailer.svg" alt="NPM version" height="18"></a> <a href="https://www.npmjs.com/package/nodemailer"><img src="https://img.shields.io/npm/dt/nodemailer.svg" alt="NPM downloads" height="18"></a>

### Community version

This is the community version of Nodemailer ([usage docs](https://community.nodemailer.com/)). Community meaning minimal maintenance and support by the author.

For an upgraded and up to date **Nodemailer PRO** see [nodemailer.com](https://nodemailer.com/) homepage.

--------------------------------------------------------------------------------

The Nodemailer logo was designed by [Sven Kristjansen](https://www.behance.net/kristjansen).

TypeScript is authored by:
* Aaron Holmes
* Abubaker Bashir
* Adam Freidin
* Adi Dahiya
* Adrian Leonhard 
* Ahmad Farid
* Akshar Patel
* Alan Agius 
* Alex Chugaev 
* Alex Eagle
* Alex Khomchenko 
* Alexander Kuvaev
* Alexander Rusakov 
* Ali Sabzevari
* Aliaksandr Radzivanovich
* Aluan Haddad 
* Anatoly Ressin 
* Anders Hejlsberg
* Andreas Martin
* Andrej Baran 
* Andrew Casey 
* Andrew Ochsner 
* Andrew Stegmaier 
* Andrew Z Allen
* András Parditka 
* Andy Hanson
* Anil Anar
* Anton Khlynovskiy 
* Anton Tolmachev
* Anubha Mathur 
* Armando Aguirre 
* Arnaud Tournier 
* Arnav Singh
* Arthur Ozga
* Asad Saeeduddin
* Avery Morin
* Basarat Ali Syed
* Ben Duffield
* Ben Mosher 
* Benjamin Bock 
* Benjamin Lichtman 
* Benny Neugebauer 
* Bill Ticehurst
* Blaine Bublitz 
* Blake Embrey
* @bootstraponline
* Bowden Kelly
* Brett Mayen
* Bryan Forbes
* Caitlin Potter
* Cameron Taggart 
* @cedvdb
* Charles Pierce 
* Charly POLY 
* Chris Bubernak
* Christophe Vidal 
* Chuck Jazdzewski
* Colby Russell
* Colin Snover
* Cotton Hou 
* csigs 
* Cyrus Najmabadi
* Dafrok Zhang
* Dahan Gong
* Dan Corder
* Dan Quirk
* Daniel Hollocher
* Daniel Król 
* Daniel Lehenbauer
* Daniel Rosenwasser
* David Kmenta
* David Li
* David Sheldrick 
* David Souther
* Denis Nedelyaev
* Dick van den Brink
* Diogo Franco (Kovensky) 
* Dirk Bäumer
* Dirk Holtwick
* Dom Chen 
* Donald Pipowitch 
* Doug Ilijev
* @e-cloud
* Elisée Maurer
* Emilio García-Pumarino
* Eric Tsang
* Erik Edrosa
* Erik McClenney 
* Ethan Resnick 
* Ethan Rubio
* Eugene Timokhov 
* Evan Martin
* Evan Sebastian
* Eyas Sharaiha
* Fabian Cook 
* @falsandtru
* Filipe Silva 
* @flowmemo
* Francois Wouts 
* Frank Wallis
* Franklin Tse
* František Žiacik
* Gabe Moothart 
* Gabriel Isenberg
* Gilad Peleg
* Godfrey Chan 
* Graeme Wicksted
* Guilherme Oenning
* Guillaume Salles
* Guy Bedford
* Halasi Tamás 
* Harald Niesche
* Hendrik Liebau 
* Henry Mercer 
* Herrington Darkholme
* Homa Wong 
* Iain Monro
* @IdeaHunter
* Igor Novozhilov
* Ika 
* Ingvar Stepanyan
* Isiah Meadows
* Ivan Enderlin 
* Ivo Gabe de Wolff
* Iwata Hidetaka 
* Jakub Korzeniowski
* Jakub Młokosiewicz 
* James Henry 
* James Whitney
* Jan Melcher 
* Jason Freeman
* Jason Jarrett 
* Jason Killian
* Jason Ramsay
* JBerger
* Jed Mao
* Jeffrey Morlan
* Jesse Schalken
* Jing Ma 
* Jiri Tobisek
* Joe Calzaretta 
* Joe Chung 
* Joel Day 
* Joey Wilson
* Johannes Rieken
* John Vilk
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Toland
* Jonathan Turner
* Jonathon Smith
* Josh Abernathy 
* Josh Goldberg 
* Josh Kalderimis
* Josh Soref
* Juan Luis Boya García
* Julian Williams
* Justin Bay 
* Justin Johansson 
* K. Preißer
* Kagami Sascha Rosylight
* Kanchalai Tanglertsampan
* Kate Miháliková 
* Keith Mashinter
* Ken Howard
* Kenji Imamula
* Kevin Lang 
* Kitson Kelly 
* Klaus Meinhardt 
* Kris Zyp 
* Kyle Kelley
* Kārlis Gaņģis
* Lorant Pinter
* Lucien Greathouse
* Lukas Elmer 
* Magnus Hiie 
* Magnus Kulke 
* Manish Giri
* Marin Marinov
* Marius Schulz 
* Martin Hiller 
* Martin Vseticka
* Masahiro Wakame
* Matt 
* Matt Bierner 
* Matt McCutchen
* Matt Mitchell 
* Mattias Buelens
* Mattias Buelens 
* Max Deepfield
* Maxwell Paul Brickner 
* @meyer
* Micah Zoltu
* @micbou
* Michael 
* Michael Bromley
* Mike Busyrev 
* Mike Morearty 
* Mine Starks 
* Mohamed Hegazy
* Mohsen Azimi 
* Myles Megyesi 
* Natalie Coley
* Nathan Shively-Sanders
* Nathan Yee
* Nicolas Henry
* @nieltg
* Nima Zahedi
* Noah Chen 
* Noel Varanda 
* Noj Vek
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Omer Sheikh 
* Orta Therox
* Oskar Segersva¨rd
* Oussama Ben Brahim 
* Patrick Zhong
* Paul Jolly
* Paul van Brenk
* @pcbro
* Pedro Maltez
* Perry Jiang
* Peter Burns
* Philip Bulley
* Piero Cangianiello
* @piloopin
* Prayag Verma
* Priyantha Lankapura 
* @progre
* Punya Biswal
* Rado Kirov
* Raj Dosanjh
* Reiner Dolp 
* Remo H. Jansen 
* Richard Karmazín 
* Richard Knoll
* Richard Sentino
* Robert Coie
* Rohit Verma
* Ron Buckton
* Rostislav Galimsky 
* Rowan Wyborn
* Ryan Cavanaugh
* Ryohei Ikegami
* Sam El-Husseini 
* Sarangan Rajamanickam
* Sean Barag 
* Sergey Rubanov
* Sergey Shandar 
* Sharon Rolel 
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon Hürlimann
* Slawomir Sadziak 
* Solal Pirelli
* Soo Jae Hwang 
* Stan Thomas
* Stanislav Iliev 
* Stanislav Sysoev
* Stas Vilchik 
* Steve Lucco
* Sudheesh Singanamalla 
* Sébastien Arod
* @T18970237136
* @t_
* Taras Mankovski 
* Tarik Ozket
* Tetsuharu Ohzeki
* Thomas den Hollander 
* Thomas Loubiou
* Tien Hoanhtien
* Tim Lancina 
* Tim Perry
* Tim Viiding-Spader
* Tingan Ho
* Todd Thomson
* togru
* Tomas Grubliauskas
* Torben Fitschen 
* @TravCav
* TruongSinh Tran-Nguyen
* Tycho Grouwstra 
* Vadi Taslim 
* Vakhurin Sergey 
* Vidar Tonaas Fauske
* Viktor Zozulyak
* Vilic Vane
* Vladimir Kurchatkin 
* Vladimir Matveev
* Wenlu Wang 
* Wesley Wigham
* William Orr 
* Wilson Hobbs 
* York Yao
* @yortus
* Yuichi Nukiyama
* Yuval Greenfield 
* Zeeshan Ahmed 
* Zev Spitz
* Zhengbo Li
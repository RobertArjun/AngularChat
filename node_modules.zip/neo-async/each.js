'use stirct';

module.exports = require('./async').each;

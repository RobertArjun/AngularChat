var calc = require('algo').calc;

module.exports = function (x) { return calc(x); }

import x from 'y';
export default z;

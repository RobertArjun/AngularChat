var a = { ...b }
;({ d, ...e } = a)

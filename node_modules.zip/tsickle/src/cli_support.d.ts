/// <amd-module name="tsickle/src/cli_support" />
export declare function pathToModuleName(context: string, fileName: string): string;

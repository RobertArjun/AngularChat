var Attr = require("../util").FileAttr,
    Zip = require("../adm-zip"),
    fs = require("fs");

//zip.addLocalFile("./test/readonly.txt");

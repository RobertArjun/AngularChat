var walk = require('acorn/dist/walk')

module.exports = walk

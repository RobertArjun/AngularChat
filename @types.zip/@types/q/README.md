# Installation
> `npm install --save @types/q`

# Summary
This package contains type definitions for Q (https://github.com/kriskowal/q).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/q

Additional Details
 * Last updated: Wed, 05 Oct 2016 20:53:38 GMT
 * File structure: UMD
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Q

# Credits
These definitions were written by Barrie Nemetchek <https://github.com/bnemetchek>, Andrew Gaspar <https://github.com/AndrewGaspar/>, John Reilly <https://github.com/johnnyreilly>.

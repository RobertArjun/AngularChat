export const environment = {
  production: true,
  firebase: {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: 'angular-chat-fca80',
    storageBucket: 'angular-chat-fca80.appspot.com',
    messagingSenderId: ''
      }
};

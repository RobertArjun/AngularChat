export declare function stripBom(data: string): string;

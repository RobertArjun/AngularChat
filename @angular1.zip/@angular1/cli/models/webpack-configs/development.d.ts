import { NamedModulesPlugin } from 'webpack';
import { WebpackConfigOptions } from '../webpack-config';
export declare function getDevConfig(_wco: WebpackConfigOptions): {
    plugins: NamedModulesPlugin[];
};

export interface GetOptions {
    global?: boolean;
}
declare const GetCommand: any;
export default GetCommand;

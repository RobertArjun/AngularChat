declare const _default: any;
export default _default;
